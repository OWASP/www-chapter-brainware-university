### Brainware University Information
* BRAINWARE UNIVERSITY,INDIA

### Social Links
* [Meetup] http://www.meetup.com/OWASP-BRAINWARE-UNIVERSITY
* [twitter] https://twitter.com/owasp_brainware
* [slack] https://owasp.slack.com